#ifndef WATER_LEVEL_H
#define WATER_LEVEL_H

// ��������
#define HX710_SCK_PIN GPIO_Pin_5
#define HX710_DT_PIN GPIO_Pin_6
#define HX710_GPIO_PORT GPIOA

void Init_Hx710(void);
unsigned long HX710_Read(void);
//void Get_Pressure_Zero(void);
unsigned int Get_Pressure(void);

#endif
