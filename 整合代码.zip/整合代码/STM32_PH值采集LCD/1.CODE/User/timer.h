#include "stm32f10x.h"


extern  void TIM3_Init(void);
void UartASendStr (u8 *pucStr, u8 ulNum) ;
extern void MKB0803_Data(void);
